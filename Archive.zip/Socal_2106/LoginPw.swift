//
//  LoginPw.swift
//  Socal_2106
//
//  Created by Long Bui on 6/22/21.
//


import UIKit


class user: Codable {
    let Rel: String
    
    init(Rel: String){
        self.Rel = Rel
        
    }

}
