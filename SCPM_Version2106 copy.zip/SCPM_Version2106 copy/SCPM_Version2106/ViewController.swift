//
//  ViewController.swift
//  SCPM_Version2106
//
//  Created by Long Bui on 6/22/21.
//

import UIKit
import CryptoKit
import Foundation
import CommonCrypto

class ViewController: UIViewController {

    //Khai bao o dang nhap username
    @IBOutlet weak var _username: UITextField!
    //Khai bao o dang nhap password
    @IBOutlet weak var _password: UITextField!
    
    @IBAction func onSigninTapped(_ sender: Any) {
        print("hello")
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var _signin_button: UIView!
    
    func sha512Base64(string: String) -> String? {
        guard let data = string.data(using: String.Encoding.utf8) else {
            return nil
        }

        var digest = Data(count: Int(CC_SHA512_DIGEST_LENGTH))
        _ = digest.withUnsafeMutableBytes { digestBytes -> UInt8 in
            data.withUnsafeBytes { messageBytes -> UInt8 in
                if let mb = messageBytes.baseAddress, let db = digestBytes.bindMemory(to: UInt8.self).baseAddress {
                    let length = CC_LONG(data.count)
                    CC_SHA512(mb, length, db)
                }
                return 0
            }
        }
        return digest.base64EncodedString()
    }


}

/*
 
 //
 //  ViewController.swift
 //  Login_Test
 //
 //  Created by Long Bui on 2/20/21.
 //

 import UIKit
 import CryptoKit
 import Foundation
 import CommonCrypto


 class ViewController: UIViewController {

     override func viewDidLoad() {
         super.viewDidLoad()
         
         let test = sha512Base64(string: "1234456")
         //let test = sha512Base64(string: "")
         
         print(test!)
         
     }
     func sha512Base64(string: String) -> String? {
         guard let data = string.data(using: String.Encoding.utf8) else {
             return nil
         }

         var digest = Data(count: Int(CC_SHA512_DIGEST_LENGTH))
         _ = digest.withUnsafeMutableBytes { digestBytes -> UInt8 in
             data.withUnsafeBytes { messageBytes -> UInt8 in
                 if let mb = messageBytes.baseAddress, let db = digestBytes.bindMemory(to: UInt8.self).baseAddress {
                     let length = CC_LONG(data.count)
                     CC_SHA512(mb, length, db)
                 }
                 return 0
             }
         }
         return digest.base64EncodedString()
     }
     

 }



 //override func viewDidLoad() {
 //    super.viewDidLoad()
    
     //Cach nay gan chuoi vao password tang them do bao mat
 //        let secret = "my-secret"
 //        let key = SymmetricKey(data: secret.data(using: .utf8)!)
 //
 //        let string = ".123456987"
 //
 //        let signature = HMAC<SHA512>.authenticationCode(for: string.data(using: .utf8)!, using: key)
 //
 //        print(Data(signature).map { String(format: "%02hhx", $0) }.joined() )
     
     //Cach khac
 //        let pass1 = SHA512.hash(data: ".123456789".data(using: .utf8)!.base64EncodedData())
 //
 //        print(pass1)

 */

